# FileApplication-Android-App-using-Android-Studio
File Application is a android app which creates a text file in MKSDCard and  with buttons of cut, copy and paste in an another txt file.
